// ============================================
// 全局搜索 ⌘K — 跨板块搜索
// ============================================

function GlobalSearch({ isOpen, onClose, onNavigate, isNight, textColor, subTextColor }) {
  const t = DESIGN_TOKENS;
  const [query, setQuery] = React.useState('');
  const [activeTab, setActiveTab] = React.useState('all');

  const inputRef = React.useRef(null);

  // 搜索历史（存在 localStorage）
  const [searchHistory, setSearchHistory] = React.useState(() => {
    try {
      const saved = localStorage.getItem('oneos-search-history');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const addToHistory = (term) => {
    if (!term || term.trim().length < 2) return;
    setSearchHistory(prev => {
      const filtered = prev.filter(h => h !== term.trim());
      const next = [term.trim(), ...filtered].slice(0, 8);
      try { localStorage.setItem('oneos-search-history', JSON.stringify(next)); } catch (e) {}
      return next;
    });
  };

  React.useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // 搜索结果
  const getResults = () => {
    const q = query.toLowerCase().trim();
    if (!q) return { notes: [], topics: [], humans: [], circles: [], commands: [], ai: [] };

    // 从全局状态获取实时笔记列表
    const globalNotes = window.OneOSAppState?.getState?.().notes || [];
    const allNotes = [
      ...globalNotes.map(n => ({
        title: n.title,
        type: 'note',
        path: `${n.topic || '未分类'}/${n.title}.md`,
        date: n.date || '今天',
      })),
      { title: '知识升维方法论', type: 'note', path: '日常思考/知识升维方法论.md', date: '2026-03-18' },
      { title: '存在与时间 读书笔记', type: 'note', path: '哲学读书笔记/存在与时间.md', date: '2026-03-15' },
      { title: '人类节点系统设计', type: 'note', path: '产品思考/人类节点系统.md', date: '2026-03-12' },
      { title: '每日随笔 0318', type: 'note', path: '日常思考/2026-03-18.md', date: '2026-03-18' },
      { title: '音色开放的边界讨论', type: 'note', path: '产品思考/音色边界.md', date: '2026-03-10' },
    ];

    const allTopics = [
      { title: '升维功能的交互设计讨论', type: 'topic', circle: 'OneOS 核心研发圈' },
      { title: '注意力残留：为什么我们很难深度思考', type: 'topic', circle: '深度思考同频圈' },
      { title: '知识升维到底升的是什么？', type: 'topic', circle: '深度思考同频圈' },
    ];

    const allHumans = [
      { name: '何思齐', type: 'human', role: '产品合伙人', topics: 5 },
      { name: '林知秋', type: 'human', role: '哲学研究员', topics: 4 },
      { name: '苏晚晴', type: 'human', role: '心理咨询师', topics: 3 },
      { name: '沈听澜', type: 'human', role: '作家', topics: 2 },
    ];

    const allCircles = [
      { name: 'OneOS 核心研发圈', type: 'circle', members: 8, topic: 'OneOS架构' },
      { name: '深度思考同频圈', type: 'circle', members: 6, topic: '哲学与认知' },
    ];

    const allAI = [
      { title: '关于注意力残留的讨论', type: 'ai', snippet: '为什么我们明明休息了，却还是觉得累？' },
      { title: '海德格尔存在论梳理', type: 'ai', snippet: '存在与时间第一篇的核心概念梳理' },
      { title: 'OneOS 产品哲学对话', type: 'ai', snippet: '关于主体性、工具服务于人的讨论' },
    ];

    const allCommands = [
      { label: '新建笔记', type: 'command', shortcut: '⌘N', action: 'editor-new' },
      { label: '切换专注模式', type: 'command', shortcut: '⌘⇧F', action: 'focus-mode' },
      { label: '打开设置', type: 'command', shortcut: '⌘,', action: 'settings' },
      { label: '升维今日笔记', type: 'command', shortcut: '', action: 'elevate-today' },
      { label: '打开全局搜索', type: 'command', shortcut: '⌘K', action: '' },
      { label: '切换到仪表盘', type: 'command', shortcut: '', action: 'dashboard' },
    ];

    const matches = (text) => text.toLowerCase().includes(q);

    const notes = allNotes.filter(n => matches(n.title) || matches(n.path));
    const topics = allTopics.filter(t => matches(t.title) || matches(t.circle));
    const humans = allHumans.filter(h => matches(h.name) || matches(h.role));
    const circles = allCircles.filter(c => matches(c.name) || matches(c.topic));
    const commands = allCommands.filter(c => matches(c.label));
    const ai = allAI.filter(a => matches(a.title) || matches(a.snippet));

    return { notes, topics, humans, circles, commands, ai };
  };

  const results = getResults();
  const totalCount = results.notes.length + results.topics.length + results.humans.length + results.circles.length + results.commands.length + results.ai.length;

  const tabCounts = {
    all: totalCount,
    notes: results.notes.length,
    topics: results.topics.length,
    humans: results.humans.length,
    circles: results.circles.length,
    ai: results.ai.length,
  };

  const tabs = [
    { id: 'all', label: '全部' },
    { id: 'notes', label: '笔记' },
    { id: 'topics', label: '话题' },
    { id: 'humans', label: '人' },
    { id: 'circles', label: '圈子' },
    { id: 'ai', label: 'AI对话' },
  ];

  if (!isOpen) return null;

  const typeLabels = {
    note: '笔记',
    topic: '话题',
    human: '人',
    circle: '圈子',
    command: '操作',
    ai: 'AI对话',
  };

  const typeColors = {
    note: t.colors.accentTeal,
    topic: t.colors.accentPrimary,
    human: t.colors.accentOrange,
    circle: t.colors.accentPink,
    command: t.colors.accentGold,
    ai: t.colors.accentPurple || '#9B6BA0',
  };

  const handleSelect = (type, id, navId) => {
    if (query.trim()) addToHistory(query);
    if (navId) onNavigate(navId);
    onClose();
    setQuery('');
  };

  const renderResultItem = (item, navId) => {
    const color = typeColors[item.type] || t.colors.textTertiary;
    const label = item.type === 'human' ? item.name : item.type === 'circle' ? item.name : item.title;
    const sub = item.type === 'note'
      ? item.path
      : item.type === 'topic'
      ? item.circle
      : item.type === 'human'
      ? `${item.role} · ${item.topics}个话题`
      : item.type === 'circle'
      ? `${item.topic} · ${item.members}人`
      : '快捷操作';

    return (
      <div
        key={label + item.type}
        onClick={() => handleSelect(item.type, label, navId)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '10px 14px',
          borderRadius: t.radius.md,
          cursor: 'pointer',
          transition: t.transition.fast,
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = t.colors.bgGlassHover;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'transparent';
        }}
      >
        <div style={{
          width: 32, height: 32,
          borderRadius: 8,
          background: `${color}20`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: color,
          fontSize: 10,
          fontWeight: 500,
          fontFamily: t.fonts.serif,
          flexShrink: 0,
        }}>
          {item.type === 'note' ? '◈'
            : item.type === 'topic' ? '◇'
            : item.type === 'human' ? (item.name?.[0] || '人')
            : item.type === 'circle' ? '◉'
            : '⌘'}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontSize: 13,
            color: t.colors.textPrimary,
            fontFamily: t.fonts.serif,
            fontWeight: 500,
            marginBottom: 2,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
            {label}
          </div>
          <div style={{
            fontSize: 11,
            color: t.colors.textTertiary,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
            {sub}
          </div>
        </div>
        {item.shortcut && (
          <span style={{
            padding: '2px 6px',
            borderRadius: 4,
            background: t.colors.bgGlass,
            border: `1px solid ${t.colors.borderSubtle}`,
            fontFamily: t.fonts.mono,
            fontSize: 10,
            color: t.colors.textTertiary,
          }}>
            {item.shortcut}
          </span>
        )}
        <span className="chip" style={{
          background: `${color}15`,
          color: color,
          border: 'none',
          fontSize: 10,
        }}>
          {typeLabels[item.type]}
        </span>
      </div>
    );
  };

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(45, 55, 72, 0.35)',
        backdropFilter: 'blur(8px)',
        zIndex: 3000,
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingTop: 120,
        animation: 'fadeIn 150ms ease both',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 580,
          maxWidth: '90vw',
          maxHeight: '65vh',
          background: 'rgba(255, 255, 255, 0.85)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          borderRadius: t.radius.xxl,
          border: '1px solid rgba(255, 255, 255, 0.9)',
          boxShadow: '0 24px 64px rgba(45, 55, 72, 0.18)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          animation: 'fadeInDown 300ms cubic-bezier(0.2, 0.8, 0.2, 1) both',
        }}
      >
        {/* 搜索输入 */}
        <div style={{
          padding: '16px 20px',
          borderBottom: `1px solid ${t.colors.borderSubtle}`,
          display: 'flex',
          alignItems: 'center',
          gap: 12,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={t.colors.textTertiary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索笔记、话题、人、圈子、操作..."
            style={{
              flex: 1,
              border: 'none',
              background: 'transparent',
              color: t.colors.textPrimary,
              fontSize: 15,
              outline: 'none',
              fontFamily: t.fonts.rounded,
              fontWeight: 500,
            }}
          />
          <kbd style={{
            padding: '3px 7px',
            borderRadius: 5,
            background: t.colors.bgGlass,
            border: `1px solid ${t.colors.borderSubtle}`,
            fontFamily: t.fonts.mono,
            fontSize: 11,
            color: t.colors.textTertiary,
          }}>
            Esc
          </kbd>
        </div>

        {/* Tab 切换 */}
        <div style={{
          display: 'flex',
          gap: 2,
          padding: '10px 14px 0',
          borderBottom: `1px solid ${t.colors.borderSubtle}`,
          overflowX: 'auto',
        }}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '6px 14px',
                borderRadius: `${t.radius.md} ${t.radius.md} 0 0`,
                border: 'none',
                borderBottom: `2px solid ${activeTab === tab.id ? t.colors.accentPrimary : 'transparent'}`,
                background: 'transparent',
                color: activeTab === tab.id ? t.colors.accentPrimary : t.colors.textTertiary,
                fontSize: 12,
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                fontWeight: activeTab === tab.id ? 500 : 400,
                fontFamily: activeTab === tab.id ? t.fonts.serif : t.fonts.sans,
                transition: t.transition.fast,
              }}
            >
              {tab.label}
              <span style={{
                marginLeft: 6,
                fontSize: 10,
                opacity: 0.6,
                fontFamily: t.fonts.mono,
              }}>
                {tabCounts[tab.id]}
              </span>
            </button>
          ))}
        </div>

        {/* 搜索结果 */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '10px',
        }}>
          {!query && searchHistory.length > 0 && (
            <div style={{ padding: '10px 8px' }}>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 10px',
                fontFamily: t.fonts.mono,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
                <span>搜索历史</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSearchHistory([]);
                    try { localStorage.removeItem('oneos-search-history'); } catch (e) {}
                  }}
                  style={{
                    fontSize: 10,
                    color: t.colors.textTertiary,
                    background: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    textTransform: 'none',
                    letterSpacing: 0,
                    fontFamily: 'inherit',
                  }}
                >
                  清除
                </button>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {searchHistory.map((term, i) => (
                  <button
                    key={i}
                    onClick={() => setQuery(term)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '8px 12px',
                      borderRadius: 8,
                      background: 'transparent',
                      border: 'none',
                      color: t.colors.textSecondary,
                      fontSize: 13,
                      cursor: 'pointer',
                      textAlign: 'left',
                      width: '100%',
                      transition: t.transition.fast,
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = t.colors.bgGlass}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={t.colors.textTertiary} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!query && searchHistory.length === 0 && (
            <div style={{
              padding: '40px 20px',
              textAlign: 'center',
              color: t.colors.textTertiary,
              fontSize: 13,
            }}>
              <p style={{ marginBottom: 10 }}>
                <span style={{ fontSize: 28 }}>🔍</span>
              </p>
              <p style={{ margin: '0 0 6px', color: t.colors.textSecondary, fontFamily: t.fonts.serif }}>
                搜索所有内容
              </p>
              <p style={{ margin: 0, fontSize: 12, opacity: 0.7 }}>
                笔记、话题、人、圈子、AI对话、操作命令<br />
                输入关键词开始搜索
              </p>
            </div>
          )}

          {query && totalCount === 0 && (
            <div style={{
              padding: '40px 20px',
              textAlign: 'center',
              color: t.colors.textTertiary,
              fontSize: 13,
            }}>
              <p style={{ margin: '0 0 6px', fontFamily: t.fonts.serif }}>
                没有找到 "{query}"
              </p>
              <p style={{ margin: 0, fontSize: 12, opacity: 0.7 }}>
                试试其他关键词，或检查拼写
              </p>
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'commands') && results.commands.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                操作
              </div>
              {results.commands.map(item => renderResultItem(item))}
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'notes') && results.notes.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                笔记
              </div>
              {results.notes.map(item => renderResultItem(item, 'editor'))}
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'topics') && results.topics.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                话题
              </div>
              {results.topics.map(item => renderResultItem(item, 'circles'))}
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'humans') && results.humans.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                人
              </div>
              {results.humans.map(item => renderResultItem(item, 'nodes'))}
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'circles') && results.circles.length > 0 && (
            <div>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                圈子
              </div>
              {results.circles.map(item => renderResultItem(item, 'circles'))}
            </div>
          )}

          {(activeTab === 'all' || activeTab === 'ai') && results.ai.length > 0 && (
            <div>
              <div style={{
                fontSize: 10,
                textTransform: 'uppercase',
                letterSpacing: 1,
                color: t.colors.textTertiary,
                padding: '8px 10px 4px',
                fontFamily: t.fonts.mono,
              }}>
                AI 对话
              </div>
              {results.ai.map(item => renderResultItem(item, 'ai'))}
            </div>
          )}
        </div>

        {/* 底部提示 */}
        <div style={{
          padding: '10px 16px',
          borderTop: `1px solid ${t.colors.borderSubtle}`,
          display: 'flex',
          alignItems: 'center',
          gap: 16,
          fontSize: 10,
          color: t.colors.textTertiary,
          fontFamily: t.fonts.mono,
        }}>
          <span>↑↓ 导航</span>
          <span>↵ 选择</span>
          <span>Esc 关闭</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GlobalSearch });
